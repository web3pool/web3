const a="/assets/no-data-19cae2a8.webp";export{a as _};
